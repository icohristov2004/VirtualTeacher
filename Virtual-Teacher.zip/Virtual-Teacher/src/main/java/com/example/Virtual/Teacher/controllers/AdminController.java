package com.example.Virtual.Teacher.controllers;

import com.example.Virtual.Teacher.models.Announcement;
import com.example.Virtual.Teacher.models.Course;
import com.example.Virtual.Teacher.models.User;
import com.example.Virtual.Teacher.service.AnnouncementService;
import com.example.Virtual.Teacher.service.CourseService;
import com.example.Virtual.Teacher.service.EnrollmentService;
import com.example.Virtual.Teacher.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private AnnouncementService announcementService;

    @Autowired
    private UserService userService;

    @Autowired
    private CourseService courseService;

    @Autowired
    private EnrollmentService enrollmentService;

    @GetMapping("/dashboard")
    public String showAdminDashboard(Model model, HttpSession session) {

        User user = (User) session.getAttribute("currentUser");
        User currentUser = (User) session.getAttribute("currentUser");
        model.addAttribute("currentUser", currentUser);
        model.addAttribute("user", user);

        if (user == null) {
            return "redirect:/login";
        }

        List<Announcement> announcements = announcementService.findAll();

        if (!announcements.isEmpty()) {
            model.addAttribute("latestAnnouncement", announcements.get(announcements.size() - 1).getContent());
        }


        model.addAttribute("announcement", new Announcement());
        model.addAttribute("announcements", announcements);

        // Load users
        List<User> users = userService.getAllUsers();
        model.addAttribute("users", users);

        // Load courses
        List<Course> courses = courseService.getAll();
        model.addAttribute("courses", courses);

        // Load report data
        long totalUsers = userService.countUsers();
        long totalCourses = courseService.countCourses();
        long totalEnrollments = enrollmentService.countEnrollments();

        model.addAttribute("totalUsers", totalUsers);
        model.addAttribute("totalCourses", totalCourses);
        model.addAttribute("totalEnrollments", totalEnrollments);

        return "adminDashboard";
    }

    // User management
    @GetMapping("/users/delete/{id}")
    public String deleteUser(@PathVariable Long id) {
        userService.deleteUserById(id);
        return "redirect:/admin/dashboard";
    }

    // Course management
    @GetMapping("/courses/delete/{id}")
    public String deleteCourse(@PathVariable Long id) {
        courseService.deleteCourseReferences(id);
        courseService.deleteById(id);
        return "redirect:/admin/dashboard";
    }

    // Announcement management
    @PostMapping("/announcements/save")
    public String saveAnnouncement(@ModelAttribute Announcement announcement) {
        announcementService.save(announcement);
        return "redirect:/admin/dashboard";
    }

    @GetMapping("/announcements/delete/{id}")
    public String deleteAnnouncement(@PathVariable Long id) {
        announcementService.deleteById(id);
        return "redirect:/admin/dashboard";
    }
}
