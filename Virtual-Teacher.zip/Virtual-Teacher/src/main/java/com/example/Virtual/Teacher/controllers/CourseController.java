package com.example.Virtual.Teacher.controllers;

import com.example.Virtual.Teacher.dto.CourseDto;
import com.example.Virtual.Teacher.dto.LectureDto;
import com.example.Virtual.Teacher.models.*;
import com.example.Virtual.Teacher.repository.AssignmentRepository;
import com.example.Virtual.Teacher.repository.CourseRepository;
import com.example.Virtual.Teacher.repository.LectureRepository;
import com.example.Virtual.Teacher.repository.RatingRepository;
import com.example.Virtual.Teacher.service.AnnouncementService;
import com.example.Virtual.Teacher.service.CourseService;
import com.example.Virtual.Teacher.service.EnrollmentService;
import com.example.Virtual.Teacher.service.UserService;
import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Controller
@RequestMapping("/courses")
public class CourseController {

    @Autowired
    private UserService userService;

    @Autowired
    private CourseService courseService;

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private AssignmentRepository assignmentRepository;

    @Autowired
    private LectureRepository lectureRepository;

    @Autowired
    private EnrollmentService enrollmentService;

    @Autowired
    private RatingRepository ratingRepository;

    @Autowired
    private AnnouncementService announcementService;


    public CourseController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/courseList")
    public String getCourseList(@RequestParam(value = "sort", required = false) String sort, Model model, HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        List<Course> courses;

        if ("newest".equals(sort)) {
            courses = courseService.getAllCoursesSortedByNewest();
        } else if ("oldest".equals(sort)) {
            courses = courseService.getAllCoursesSortedByOldest();
        } else if ("nameAsc".equals(sort)) {
            courses = courseService.getAllCoursesSortedByTitleAsc();
        } else {
            courses = courseService.getAll();
        }

        Map<Long, Boolean> enrollmentStatusMap = new HashMap<>();

        if (currentUser != null) {
            for (Course course : courses) {
                boolean isEnrolled = enrollmentService.isUserEnrolledInCourse(course.getId(), currentUser.getId());
                enrollmentStatusMap.put(course.getId(), isEnrolled);
            }
        }


        model.addAttribute("courses", courses);
        model.addAttribute("enrollmentStatusMap", enrollmentStatusMap);
        model.addAttribute("currentUser", currentUser);
        model.addAttribute("sort", sort);
        return "courses";
    }


    @GetMapping("/new")
    public String showAddCoursePage(Model model, HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        model.addAttribute("currentUser", currentUser);
        model.addAttribute("course", new Course());
        List<Announcement> announcements = announcementService.findAll();
        if (!announcements.isEmpty()) {
            model.addAttribute("latestAnnouncement", announcements.get(announcements.size() - 1).getContent());
        }
        model.addAttribute("announcements", announcements);
        return "createCourse";
    }

    @PostMapping("/new")
    public String handleCreateCourse(@ModelAttribute("course") CourseDto courseDto,
                                     @RequestParam("courseImage") MultipartFile courseImage,
                                     @RequestParam("assignmentFiles") List<MultipartFile> assignmentFiles,
                                     HttpSession session) {

        try {
            User user = (User) session.getAttribute("currentUser");
            if (user == null) {
                return "redirect:/login";
            }


            Course course = new Course();
            course.setTitle(courseDto.getTitle());
            course.setDescription(courseDto.getDescription());
            course.setAuthor(user);


            String imageUrl = null;
            if (!courseImage.isEmpty()) {
                String originalFilename = courseImage.getOriginalFilename();
                Path imagePath = Paths.get("src/main/resources/static/course-images/" + originalFilename);
                Files.write(imagePath, courseImage.getBytes());
                imageUrl = "/static/course-images/" + originalFilename;
            }
            course.setPhotoUrl(imageUrl);


            for (int i = 0; i < courseDto.getLectures().size(); i++) {
                LectureDto lectureDto = courseDto.getLectures().get(i);
                Lecture lecture = new Lecture();
                lecture.setTitle(lectureDto.getTitle());
                lecture.setVideoLink(lectureDto.getVideoLink());
                lecture.setCourse(course);


                course.getLectures().add(lecture);


                if (i < assignmentFiles.size()) {
                    MultipartFile assignmentFile = assignmentFiles.get(i);

                    if (!assignmentFile.isEmpty()) {
                        String assignmentFileName = assignmentFile.getOriginalFilename();
                        Path assignmentPath = Paths.get("src/main/resources/static/assignments/" + assignmentFileName);
                        Files.write(assignmentPath, assignmentFile.getBytes());


                        Assignment assignment = new Assignment();
                        assignment.setFilePath(assignmentPath.toString());
                        assignment.setFileType(assignmentFile.getContentType());
                        assignment.setLecture(lecture);


                        lecture.getAssignments().add(assignment);
                    }
                }
            }


            courseService.create(course);


            return "redirect:/courses/courseList";
        } catch (IOException e) {
            e.printStackTrace();
            return "error";
        }
    }

    @GetMapping("/{id}")
    public String showCourseDetails(@PathVariable("id") Long id, Model model, HttpSession session) {

        User currentUser = (User) session.getAttribute("currentUser");
        Course course = courseService.getById(id);
        int enrollmentCount = enrollmentService.getEnrollmentCount(id);
        boolean isEnrolled = false;

        if (currentUser != null) {
            isEnrolled = enrollmentService.isUserEnrolledInCourse(id, currentUser.getId());
        }

        // Calculate the average rating for the course
        double averageRating = courseService.calculateAverageRating(id);

        model.addAttribute("course", course);
        model.addAttribute("currentUser", currentUser);
        model.addAttribute("enrollmentCount", enrollmentCount);
        model.addAttribute("isEnrolled", isEnrolled);
        model.addAttribute("averageRating", averageRating);

        return "courseDetails";
    }


    @GetMapping("/assignments/download/{id}")
    public ResponseEntity<byte[]> downloadAssignment(@PathVariable Long id) throws IOException {
        Assignment assignment = assignmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Assignment not found"));
        String filePath = assignment.getFilePath();
        System.out.println("Requested file path: " + filePath);
        Path path = Paths.get(assignment.getFilePath());
        File file = path.toFile();

        if (!file.exists()) {
            throw new RuntimeException("File not found: " + assignment.getFilePath());
        }

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(assignment.getFileType()))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getName() + "\"")
                .contentLength(file.length())
                .body(java.nio.file.Files.readAllBytes(path));
    }


    @PostMapping("/{id}/rate")
    public String rateCourse(@PathVariable("id") Long courseId,
                             @RequestParam("rating") int ratingValue,
                             HttpSession session,
                             RedirectAttributes redirectAttributes) {
        User currentUser = (User) session.getAttribute("currentUser");

        if (currentUser == null) {
            redirectAttributes.addFlashAttribute("ratingErrorMessage", "User not logged in");
            return "redirect:/courses/" + courseId;
        }

        try {
            Course course = courseService.getById(courseId);
            if (course == null) {
                redirectAttributes.addFlashAttribute("ratingErrorMessage", "Course not found");
                return "redirect:/courses/" + courseId;
            }

            Optional<Rating> existingRating = ratingRepository.findByUserIdAndCourseId(currentUser.getId(), courseId);

            if (existingRating.isPresent()) {
                Rating rating = existingRating.get();
                rating.setValue(ratingValue);
                ratingRepository.save(rating);
            } else {
                Rating newRating = new Rating(currentUser, course, ratingValue);
                ratingRepository.save(newRating);
            }

            double averageRating = courseService.calculateAverageRating(courseId);

            redirectAttributes.addFlashAttribute("ratingMessage", "Thank you for your feedback!");
            redirectAttributes.addFlashAttribute("averageRating", averageRating);

            return "redirect:/courses/" + courseId;
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("ratingErrorMessage", "An error occurred while processing your request");
            return "redirect:/courses/" + courseId;
        }
    }


}


