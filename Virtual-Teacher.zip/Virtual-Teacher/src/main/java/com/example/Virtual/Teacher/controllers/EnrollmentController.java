package com.example.Virtual.Teacher.controllers;

import com.example.Virtual.Teacher.models.User;
import com.example.Virtual.Teacher.service.EnrollmentService;
import com.example.Virtual.Teacher.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/enrollments")
public class EnrollmentController {

    @Autowired
    private EnrollmentService enrollmentService;

    @Autowired
    private UserService userService;

    @PostMapping("/enroll/{courseId}")
    public String enrollInCourse(@PathVariable Long courseId, HttpSession session, RedirectAttributes redirectAttributes) {
        User currentUser = (User) session.getAttribute("currentUser");

        if (currentUser == null) {
            return "redirect:/login";
        }

        boolean enrolled = enrollmentService.enrollUserInCourse(courseId, currentUser.getId());

        if (enrolled) {
            redirectAttributes.addFlashAttribute("enrollmentMessage", "Successfully enrolled in the course!");
        } else {
            redirectAttributes.addFlashAttribute("enrollmentErrorMessage", "You are already enrolled in this course.");
        }

        return "redirect:/courses/" + courseId;
    }

}
