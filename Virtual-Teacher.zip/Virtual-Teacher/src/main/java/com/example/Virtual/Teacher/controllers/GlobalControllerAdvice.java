package com.example.Virtual.Teacher.controllers;

import com.example.Virtual.Teacher.models.Announcement;
import com.example.Virtual.Teacher.service.AnnouncementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

import java.util.List;

@ControllerAdvice
public class GlobalControllerAdvice {

    @Autowired
    private AnnouncementService announcementService;

    @ModelAttribute
    public void addGlobalAttributes(Model model) {
        List<Announcement> announcements = announcementService.findAll();
        if (!announcements.isEmpty()) {
            model.addAttribute("latestAnnouncement", announcements.get(announcements.size() - 1).getContent());
        }
        model.addAttribute("announcement", new Announcement());
        model.addAttribute("announcements", announcements);

    }
}