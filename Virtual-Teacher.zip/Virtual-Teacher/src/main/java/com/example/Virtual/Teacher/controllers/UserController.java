package com.example.Virtual.Teacher.controllers;


import com.example.Virtual.Teacher.dto.LoginDto;
import com.example.Virtual.Teacher.dto.RegisterDto;
import com.example.Virtual.Teacher.models.User;
import com.example.Virtual.Teacher.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping()
public class UserController {


    @Autowired
    private UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }


    @GetMapping("/home")
    public String showHomePage(Model model, HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        model.addAttribute("currentUser", currentUser);
        return "index";
    }

    @GetMapping("/register")
    public String showRegisterPage(Model model) {
        model.addAttribute("register", new RegisterDto());
        return "register";
    }

    @PostMapping("/register")
    public String registerUser(@ModelAttribute("register") RegisterDto registerDto, Model model) {
        try {
            userService.registerNewUser(registerDto);
            return "redirect:/login";
        } catch (IllegalStateException e) {
            model.addAttribute("error", e.getMessage());
            return "register";
        }
    }


    @GetMapping("/login")
    public String showLoginPage(Model model) {
        model.addAttribute("login", new LoginDto());
        return "login";
    }

    @PostMapping("/login")
    public String loginUser(@ModelAttribute("login") LoginDto loginDto, HttpSession session, Model model) {
        try {
            User existingUser = userService.getByEmail(loginDto.getEmail());

            if (existingUser != null && existingUser.getPassword().equals(loginDto.getPassword())) {
                session.setAttribute("currentUser", existingUser);
                return "redirect:/home";
            } else {
                model.addAttribute("error", "Invalid email or password");
                return "login";
            }
        } catch (Exception e) {
            model.addAttribute("errorCode", HttpStatus.INTERNAL_SERVER_ERROR.value());
            model.addAttribute("errorMessage", e.getMessage());
            return "error";
        }
    }

    @GetMapping("/profile")
    public String getProfilePage(HttpSession session, Model model) {
        User user = (User) session.getAttribute("currentUser");
        User currentUser = (User) session.getAttribute("currentUser");
        model.addAttribute("currentUser", currentUser);

        if (user == null) {
            return "redirect:/login";
        }

        model.addAttribute("user", user);
        return "profilePage";
    }

    @PostMapping("/profile/update")
    public String updateUserProfile(
            @RequestParam(value = "firstName", required = false) String firstName,
            @RequestParam(value = "lastName", required = false) String lastName,
            @RequestParam(value = "email", required = false) String email,
            @RequestParam(value = "password", required = false) String password,
            @RequestParam(value = "bio", required = false) String bio,  // New bio parameter
            HttpSession session,
            Model model,
            RedirectAttributes redirectAttributes
    ) {
        User user = (User) session.getAttribute("currentUser");

        if (user == null) {
            return "redirect:/login";
        }

        try {
            // Update user details
            if (firstName != null && !firstName.isEmpty()) {
                user.setFirstname(firstName);
            }
            if (lastName != null && !lastName.isEmpty()) {
                user.setLastname(lastName);
            }
            if (email != null && !email.isEmpty()) {
                user.setEmail(email);
            }
            if (password != null && !password.isEmpty()) {
                user.setPassword(password);
            }
            if (bio != null && !bio.isEmpty()) {
                user.setBio(bio);  // Update bio
            }

            userService.updateUser(user);

            session.setAttribute("currentUser", user);
            model.addAttribute("user", user);
            redirectAttributes.addFlashAttribute("successMessage", "Profile updated successfully!");

            return "redirect:/profile";
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());

            return "profilePage";
        }
    }

    @GetMapping("/logout")
    public String logoutUser(HttpSession session) {
        session.invalidate();
        return "redirect:/home";
    }


}

