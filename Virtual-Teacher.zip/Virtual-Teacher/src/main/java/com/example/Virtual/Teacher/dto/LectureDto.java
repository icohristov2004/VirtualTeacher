package com.example.Virtual.Teacher.dto;

import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

public class LectureDto {

    private Long id;
    private String title;
    private String description;
    private String videoLink;
    private List<MultipartFile> assignments = new ArrayList<>();

    public LectureDto() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getVideoLink() {
        return videoLink;
    }

    public void setVideoLink(String videoLink) {
        this.videoLink = videoLink;
    }

    public List<MultipartFile> getAssignments() {
        return assignments;
    }

    public void setAssignments(List<MultipartFile> assignments) {
        this.assignments = assignments;
    }
}
