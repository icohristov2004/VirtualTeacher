package com.example.Virtual.Teacher.models;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Entity
@Table(name = "COURSES")
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "COURSE_ID")
    private Long id;

    @Column(name = "COURSE_TITLE", nullable = false, length = 50)
    private String title;


    @Column(name = "COURSE_DESCRIPTION", length = 1000)
    @Lob
    private String description;

    @Column(name = "PHOTO_URL")
    private String photoUrl;

    @OneToMany(mappedBy = "course", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
    private List<Lecture> lectures = new ArrayList<>();

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "USER_ID")
    private User author;

    @ElementCollection
    @CollectionTable(name = "RATINGS", joinColumns = @JoinColumn(name = "COURSE_ID"))
    @MapKeyColumn(name = "USER_ID")
    @Column(name = "RATING_VALUE")
    private Map<Long, Integer> ratings = new HashMap<>();


    public Map<Long, Integer> getRatings() {
        return ratings;
    }

    public void setRatings(Map<Long, Integer> ratings) {
        this.ratings = ratings;
    }


    public void addRating(User user, int rating) {
        this.ratings.put(user.getId(), rating);
    }


    public double getAverageRating() {
        if (ratings.isEmpty()) return 0;
        double sum = ratings.values().stream().mapToInt(Integer::intValue).sum();
        return sum / ratings.size();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }



    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPhotoUrl() {
        return photoUrl;
    }

    public void setPhotoUrl(String photoUrl) {
        this.photoUrl = photoUrl;
    }

    public List<Lecture> getLectures() {
        return lectures;
    }

    public void setLectures(List<Lecture> lectures) {
        this.lectures = lectures;
    }

    public User getAuthor() {
        return author;
    }

    public void setAuthor(User author) {
        this.author = author;
    }

}
