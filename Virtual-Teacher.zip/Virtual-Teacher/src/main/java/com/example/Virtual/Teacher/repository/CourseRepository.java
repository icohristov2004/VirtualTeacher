package com.example.Virtual.Teacher.repository;

import com.example.Virtual.Teacher.models.Course;

import java.util.List;

public interface CourseRepository {

    List<Course> getAll();

    Course getById(Long id);
    void create( Course  course);
    void update( Course  course);
    void deleteById(Long id);
    long count();
    void deleteCourseReferences(Long courseId);
    List<Course> getAllSortedByNewest();
    List<Course> getAllSortedByOldest();
    List<Course> getAllSortedByTitleAsc();

}