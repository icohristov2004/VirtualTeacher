package com.example.Virtual.Teacher.repository;

import com.example.Virtual.Teacher.models.Course;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CourseRepositoryImpl implements CourseRepository {

    private final SessionFactory sessionFactory;

    @Autowired
    public CourseRepositoryImpl(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @Override
    public List<Course> getAll() {
        try (Session session = sessionFactory.openSession()) {
            Query<Course> query = session.createQuery("FROM Course", Course.class);
            return query.list();
        }
    }

    @Override
    public Course getById(Long id) {
        try (Session session = sessionFactory.openSession()) {
            return session.get(Course.class, id);
        }
    }

    @Override
    public void create(Course course) {
        try (Session session = sessionFactory.openSession()) {
            session.beginTransaction();
            session.save(course);
            session.getTransaction().commit();
        }
    }

    @Override
    public void update(Course course) {
        try (Session session = sessionFactory.openSession()) {
            session.beginTransaction();
            session.update(course);
            session.getTransaction().commit();
        }
    }

    @Override
    public void deleteCourseReferences(Long courseId) {
        try (Session session = sessionFactory.openSession()) {
            session.beginTransaction();

            // Delete from USER_COURSES where the course ID is the one being deleted
            Query deleteUserCourses = session.createNativeQuery("DELETE FROM USER_COURSES WHERE COURSE_ID = :courseId");
            deleteUserCourses.setParameter("courseId", courseId);
            deleteUserCourses.executeUpdate();

            // Delete related entries from ENROLLMENT where the course ID is the one being deleted
            Query deleteEnrollments = session.createNativeQuery("DELETE FROM ENROLLMENT WHERE COURSE_ID = :courseId");
            deleteEnrollments.setParameter("courseId", courseId);
            deleteEnrollments.executeUpdate();

            // Delete related entries from LECTURES where the course ID is the one being deleted
            Query deleteLectures = session.createNativeQuery("DELETE FROM LECTURES WHERE COURSE_ID = :courseId");
            deleteLectures.setParameter("courseId", courseId);
            deleteLectures.executeUpdate();

            // Delete related entries from RATINGS where the course ID is the one being deleted
            Query deleteRatings = session.createNativeQuery("DELETE FROM RATINGS WHERE COURSE_ID = :courseId");
            deleteRatings.setParameter("courseId", courseId);
            deleteRatings.executeUpdate();

            session.getTransaction().commit();
        }
    }

    @Override
    public void deleteById(Long id) {
        try (Session session = sessionFactory.openSession()) {
            session.beginTransaction();

            // Delete the course itself
            Course course = session.get(Course.class, id);
            if (course != null) {
                session.delete(course);
            }

            session.getTransaction().commit();
        }
    }

    @Override
    public long count() {
        try (Session session = sessionFactory.openSession()) {
            Query<Long> query = session.createQuery("SELECT COUNT(c) FROM Course c", Long.class);
            return query.uniqueResult();
        }
    }
    @Override
    public List<Course> getAllSortedByTitleAsc() {
        try (Session session = sessionFactory.openSession()) {
            Query<Course> query = session.createQuery("FROM Course ORDER BY title ASC", Course.class);
            return query.list();
        }
    }

    @Override
    public List<Course> getAllSortedByNewest() {
        try (Session session = sessionFactory.openSession()) {
            Query<Course> query = session.createQuery("FROM Course ORDER BY id DESC", Course.class);
            return query.list();
        }
    }

    @Override
    public List<Course> getAllSortedByOldest() {
        try (Session session = sessionFactory.openSession()) {
            Query<Course> query = session.createQuery("FROM Course ORDER BY id ASC", Course.class);
            return query.list();
        }
    }

}