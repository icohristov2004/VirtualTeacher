package com.example.Virtual.Teacher.repository;

import com.example.Virtual.Teacher.models.Course;
import com.example.Virtual.Teacher.models.Enrollment;
import com.example.Virtual.Teacher.models.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EnrollmentRepository extends JpaRepository<Enrollment, Long> {

    boolean existsByUserAndCourse(User user, Course course);

    boolean existsByUserIdAndCourseId(Long userId, Long courseId);

    int countByCourseId(Long courseId);
}