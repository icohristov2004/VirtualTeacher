package com.example.Virtual.Teacher.repository;

import com.example.Virtual.Teacher.models.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Integer> {
    Role findByRoleName(String roleName);
}