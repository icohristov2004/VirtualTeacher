package com.example.Virtual.Teacher.service;

import com.example.Virtual.Teacher.models.Assignment;
import com.example.Virtual.Teacher.repository.AssignmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AssignmentService {

    @Autowired
    private AssignmentRepository assignmentRepository;

    public void saveAssignment(Assignment assignment) {
        assignmentRepository.save(assignment);
    }

    public Assignment getAssignmentById(Long id) {
        return assignmentRepository.findById(id).orElse(null);
    }


}