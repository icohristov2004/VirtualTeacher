package com.example.Virtual.Teacher.service;

import com.example.Virtual.Teacher.models.Course;
import com.example.Virtual.Teacher.models.Rating;
import com.example.Virtual.Teacher.repository.CourseRepository;
import com.example.Virtual.Teacher.repository.RatingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CourseService {

    private final CourseRepository courseRepository;
    private final RatingRepository ratingRepository; // New repository for ratings

    @Autowired
    public CourseService(CourseRepository courseRepository, RatingRepository ratingRepository) {
        this.courseRepository = courseRepository;
        this.ratingRepository = ratingRepository; // Initialize the new repository
    }

    public List<Course> getAll() {
        return courseRepository.getAll();
    }

    public Course getById(Long id) {
        return courseRepository.getById(id);
    }

    public void create(Course course) {
        courseRepository.create(course);
    }

    public void deleteById(Long id) {
        courseRepository.deleteById(id); // JpaRepository provides deleteById()
    }

    public void deleteCourseReferences(Long courseId) {
        courseRepository.deleteCourseReferences(courseId);
    }

    public long countCourses() {
        return courseRepository.count(); // JpaRepository provides count()
    }

    public List<Course> getAllCoursesSortedByNewest() {
        return courseRepository.getAllSortedByNewest();
    }

    public List<Course> getAllCoursesSortedByOldest() {
        return courseRepository.getAllSortedByOldest();
    }

    public List<Course> getAllCoursesSortedByTitleAsc() {
        return courseRepository.getAllSortedByTitleAsc();
    }


    public void saveRating(Rating rating) {
        ratingRepository.save(rating);
    }

    public double calculateAverageRating(Long courseId) {
        List<Rating> ratings = ratingRepository.findByCourseId(courseId);
        if (ratings.isEmpty()) {
            return 0.0;
        }
        double sum = ratings.stream().mapToInt(Rating::getValue).sum();
        return sum / ratings.size();
    }
}
