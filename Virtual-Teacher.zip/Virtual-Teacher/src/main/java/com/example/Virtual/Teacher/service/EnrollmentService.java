package com.example.Virtual.Teacher.service;

import com.example.Virtual.Teacher.models.Course;
import com.example.Virtual.Teacher.models.Enrollment;
import com.example.Virtual.Teacher.models.User;
import com.example.Virtual.Teacher.repository.CourseRepository;
import com.example.Virtual.Teacher.repository.EnrollmentRepository;
import com.example.Virtual.Teacher.repository.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class EnrollmentService {


    @Autowired
    private EnrollmentRepository enrollmentRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CourseRepository courseRepository;

    public boolean enrollUserInCourse(Long courseId, Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found with id: " + userId));
        Course course = courseRepository.getById(courseId);


        if (!enrollmentRepository.existsByUserAndCourse(user, course)) {
            Enrollment enrollment = new Enrollment();
            enrollment.setUser(user);
            enrollment.setCourse(course);
            enrollment.setEnrollmentDate(LocalDateTime.now());

            enrollmentRepository.save(enrollment);
            return true;
        }

        return false; // User already enrolled
    }

    // Method to check if the user is enrolled in a course
    public boolean isUserEnrolledInCourse(Long courseId, Long userId) {
        return enrollmentRepository.existsByUserIdAndCourseId(userId, courseId);
    }

    // Method to get enrollment count for a course
    public int getEnrollmentCount(Long courseId) {
        return enrollmentRepository.countByCourseId(courseId);
    }

    // Method to count total enrollments
    public long countEnrollments() {
        return enrollmentRepository.count();
    }
}