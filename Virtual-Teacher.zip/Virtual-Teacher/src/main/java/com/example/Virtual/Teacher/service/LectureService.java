package com.example.Virtual.Teacher.service;

public class LectureService {
}
