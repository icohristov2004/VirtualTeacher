package com.example.Virtual.Teacher.service;

import com.example.Virtual.Teacher.constants.DefaultValues;
import com.example.Virtual.Teacher.dto.RegisterDto;
import com.example.Virtual.Teacher.models.Course;
import com.example.Virtual.Teacher.models.User;
import com.example.Virtual.Teacher.models.Role;
import com.example.Virtual.Teacher.repository.RoleRepository;
import com.example.Virtual.Teacher.repository.UserRepository;
import jakarta.annotation.PostConstruct;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    // Method to get all users
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    // Method to delete a user by ID
    public void deleteUserById(Long id) {
        userRepository.deleteById(id);
    }

    // Method to count total users
    public long countUsers() {
        return userRepository.count();
    }

    public User getByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    public void saveUser(User user) {
        userRepository.save(user);
    }

    public boolean userExists(String email) {
        return userRepository.findByEmail(email) != null;
    }

    public void registerNewUser(RegisterDto registerdto) {
        if (userExists(registerdto.getEmail())) {
            throw new IllegalStateException("Email already exists.");
        }

        User user = new User();
        user.setEmail(registerdto.getEmail());
        user.setPassword(registerdto.getPassword());
        user.setFirstname(registerdto.getFirstName());
        user.setLastname(registerdto.getLastName());
        user.setProfilePicture(DefaultValues.DEFAULT_PROFILE_PICTURE_URL);
        Role userRole = roleRepository.findByRoleName(registerdto.getRole());
        if (userRole == null) {
            throw new IllegalStateException("Role not found.");
        }
        user.setRole(userRole);
        userRepository.save(user);
    }

    @PostConstruct
    public void createAdminUser() {

        RegisterDto adminUser = new RegisterDto();
        adminUser.setEmail("admin@gmail.com");
        adminUser.setPassword("admin123");
        adminUser.setFirstName("Admin");
        adminUser.setLastName("User");
        adminUser.setRole("ADMIN");

        if (!userExists(adminUser.getEmail())) {
            registerNewUser(adminUser);
        }
    }

    public void updateUser(User updatedUser) {

        User existingUser = userRepository.findByEmail(updatedUser.getEmail());

        if (existingUser == null) {
            throw new IllegalArgumentException("User does not exist.");
        }

        if (updatedUser.getFirstname() != null && !updatedUser.getFirstname().isEmpty()) {
            existingUser.setFirstname(updatedUser.getFirstname());
        }
        if (updatedUser.getLastname() != null && !updatedUser.getLastname().isEmpty()) {
            existingUser.setLastname(updatedUser.getLastname());
        }
        if (updatedUser.getEmail() != null && !updatedUser.getEmail().isEmpty()) {
            existingUser.setEmail(updatedUser.getEmail());
        }

        if (updatedUser.getPassword() != null && !updatedUser.getPassword().isEmpty()) {
            existingUser.setPassword(updatedUser.getPassword());
        }

        if (updatedUser.getProfilePicture() != null && !updatedUser.getProfilePicture().isEmpty()) {
            existingUser.setProfilePicture(updatedUser.getProfilePicture());
        }

        if (updatedUser.getBio() != null && !updatedUser.getBio().isEmpty()) {
            existingUser.setBio(updatedUser.getBio());
        }

        userRepository.save(existingUser);
    }
}
