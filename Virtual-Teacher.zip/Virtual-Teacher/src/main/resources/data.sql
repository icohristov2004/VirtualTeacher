-- Insert roles
INSERT INTO ROLE (ROLE_ID, ROLE_NAME)
VALUES (1, 'STUDENT');

INSERT INTO ROLE (ROLE_ID, ROLE_NAME)
VALUES (2, 'TEACHER');

INSERT INTO ROLE (ROLE_ID, ROLE_NAME)
VALUES (3, 'ADMIN');

-- Insert users
INSERT INTO USERS (PASSWORD, FIRST_NAME, LAST_NAME, EMAIL, ROLE_ID)
VALUES ('PasswordForPetko', 'Michael', 'Smith', 'michaelsmith@email.com', 1);

INSERT INTO USERS (PASSWORD, FIRST_NAME, LAST_NAME, EMAIL, ROLE_ID)
VALUES ('PasswordForNiki', 'John', 'Doe', 'johndoe@mail.com', 2);

INSERT INTO USERS (PASSWORD, FIRST_NAME, LAST_NAME, EMAIL, ROLE_ID)
VALUES ('hanPassword', 'Paris', 'Hilton', 'parishilton@mail.com', 3);

-- Insert courses
INSERT INTO COURSES(COURSE_TITLE, COURSE_DESCRIPTION, USER_ID, PHOTO_URL)
VALUES ('A complete guide to design', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sit amet massa gravida, efficitur justo nec, scelerisque sem. Curabitur venenatis consequat purus, vitae lobortis purus scelerisque hendrerit. Nunc lobortis nec erat id pellentesque. Donec vitae purus ligula.', 1,  '../course-images/exampleimage1.jpg');

INSERT INTO COURSES(COURSE_TITLE, COURSE_DESCRIPTION, USER_ID, PHOTO_URL)
VALUES ('Beginners guide to HTML',  'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sit amet massa gravida, efficitur justo nec, scelerisque sem. Curabitur venenatis consequat purus, vitae lobortis purus scelerisque hendrerit. Nunc lobortis nec erat id pellentesque. Donec vitae purus ligula.', 1,  '../course-images/exampleimage2.jpg');

INSERT INTO COURSES(COURSE_TITLE, COURSE_DESCRIPTION, USER_ID, PHOTO_URL)
VALUES ('Advanced Photoshop tutorial', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sit amet massa gravida, efficitur justo nec, scelerisque sem. Curabitur venenatis consequat purus, vitae lobortis purus scelerisque hendrerit. Nunc lobortis nec erat id pellentesque. Donec vitae purus ligula.', 1,  '../course-images/exampleimage3.jpg');

-- Associate users and courses (if needed)
INSERT INTO USER_COURSES (COURSE_ID, USER_ID)
VALUES (1, 1);

INSERT INTO USER_COURSES (COURSE_ID, USER_ID)
VALUES (2, 2);

INSERT INTO USER_COURSES (COURSE_ID, USER_ID)
VALUES (3, 3);
