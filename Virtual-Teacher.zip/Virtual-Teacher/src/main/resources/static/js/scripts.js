
 const dropZone = document.getElementById('drop-zone');
 const fileInput = document.getElementById('courseImage');
 const browseButton = document.getElementById('browseButton');
 const changeImageButton = document.getElementById('changeImageButton');
 const imagePreview = document.getElementById('imagePreview');
 const thumbnail = document.getElementById('thumbnail');
 const successMessage = document.getElementById('successMessage');
 const loadingSpinner = document.getElementById('loadingSpinner');
 const changeImageSection = document.getElementById('changeImageSection');

 dropZone.addEventListener('dragover', (e) => {
     e.preventDefault();
     dropZone.classList.add('drag-over');
 });

 dropZone.addEventListener('dragleave', () => {
     dropZone.classList.remove('drag-over');
 });

 dropZone.addEventListener('drop', (e) => {
     e.preventDefault();
     dropZone.classList.remove('drag-over');
     const files = e.dataTransfer.files;
     if (files.length) {
         fileInput.files = files;
         handleFileUpload(files[0]);
     }
 });

 browseButton.addEventListener('click', () => {
     fileInput.click();
 });

 fileInput.addEventListener('change', () => {
     if (fileInput.files.length) {
         handleFileUpload(fileInput.files[0]);
     }
 });

 changeImageButton.addEventListener('click', () => {
     fileInput.click();
 });

 function handleFileUpload(file) {
     // Show loading spinner
     loadingSpinner.style.display = 'block';
     successMessage.style.display = 'none';
     imagePreview.style.display = 'none';
     dropZone.style.display = 'none'; // Hide drag-and-drop area
     changeImageSection.style.display = 'block'; // Show Change Image button

     const reader = new FileReader();
     reader.onload = (e) => {
         thumbnail.src = e.target.result;
         imagePreview.style.display = 'block';  // Show image preview
         loadingSpinner.style.display = 'none'; // Hide spinner
         successMessage.style.display = 'block'; // Show success message
     };
     reader.readAsDataURL(file);
 }

document.addEventListener("DOMContentLoaded", function () {
    const ratingForm = document.getElementById("ratingForm");
    const ratingBox = document.querySelector('.rating-box');

    ratingForm.addEventListener("submit", function (event) {
        event.preventDefault();  // Prevent default form submission

        const selectedRating = ratingForm.querySelector('input[name="rating"]:checked');
        if (!selectedRating) {
            alert("Please select a rating.");
            return;
        }

        const formData = new FormData(ratingForm);

        // Send the form data using fetch
        fetch(ratingForm.action, {
            method: "POST",
            body: formData
        })
        .then(response => response.json())  // Parse JSON response
        .then(data => {
            if (data.success) {
                // Dynamically update the rating section with "Thank you" message
                ratingBox.innerHTML = `
                    <h5>Thank you for your feedback!</h5>
                    <p>Average rating: ${data.averageRating.toFixed(1)} / 5</p>
                `;
            } else {
                alert(data.message || "Failed to submit rating. Please try again.");
            }
        })
        .catch(error => {
            alert("An error occurred: " + error.message);
        });
    });
});











     const dropZoneAssignment = document.getElementById('drop-zone-assignment');
     const fileInputAssignment = document.getElementById('assignmentFile');
     const browseButtonAssignment = document.getElementById('browseButtonAssignment');
     const changeAssignmentButton = document.getElementById('changeAssignmentButton');
     const assignmentPreview = document.getElementById('assignmentPreview');
     const assignmentFileName = document.getElementById('assignmentFileName');
     const assignmentSuccessMessage = document.getElementById('assignmentSuccessMessage');
     const loadingSpinnerAssignment = document.getElementById('loadingSpinnerAssignment');
     const changeAssignmentSection = document.getElementById('changeAssignmentSection');

     dropZoneAssignment.addEventListener('dragover', (e) => {
         e.preventDefault();
         dropZoneAssignment.classList.add('drag-over');
     });

     dropZoneAssignment.addEventListener('dragleave', () => {
         dropZoneAssignment.classList.remove('drag-over');
     });

     dropZoneAssignment.addEventListener('drop', (e) => {
         e.preventDefault();
         dropZoneAssignment.classList.remove('drag-over');
         const files = e.dataTransfer.files;
         if (files.length) {
             fileInputAssignment.files = files;
             handleAssignmentUpload(files[0]);
         }
     });

     browseButtonAssignment.addEventListener('click', () => {
         fileInputAssignment.click();
     });

     fileInputAssignment.addEventListener('change', () => {
         if (fileInputAssignment.files.length) {
             handleAssignmentUpload(fileInputAssignment.files[0]);
         }
     });

     changeAssignmentButton.addEventListener('click', () => {
         fileInputAssignment.click();
     });

     function handleAssignmentUpload(file) {
         loadingSpinnerAssignment.style.display = 'block';
         assignmentSuccessMessage.style.display = 'none';
         assignmentPreview.style.display = 'none';
         dropZoneAssignment.style.display = 'none';
         changeAssignmentSection.style.display = 'block';

         setTimeout(() => {
             assignmentFileName.textContent = file.name;
             assignmentPreview.style.display = 'block';
             loadingSpinnerAssignment.style.display = 'none';
             assignmentSuccessMessage.style.display = 'block';
         }, 500); // Simulating file upload delay
     }
