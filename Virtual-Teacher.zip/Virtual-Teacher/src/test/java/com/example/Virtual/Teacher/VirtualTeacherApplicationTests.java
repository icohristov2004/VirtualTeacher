package com.example.Virtual.Teacher;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VirtualTeacherApplicationTests {

	@Test
	void contextLoads() {
	}

}
